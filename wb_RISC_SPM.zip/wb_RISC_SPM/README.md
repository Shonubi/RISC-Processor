1. Make sure you have cocotb and the cocotb wishbone extension installed.

python3 -m pip install cocotbext-wishbone

2. Update the Makefile with correct module names (line 11 and 17).
3. Update the dump file
4. 